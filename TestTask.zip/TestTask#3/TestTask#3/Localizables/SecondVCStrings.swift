//
//  SecondVCStrings.swift
//  TestTask#3
//
//  Created by MaxK on 27.04.2024.
//

import Foundation

enum SecondString: String {
    case labelCountry
    case labelCountryCode
    case labelRegion
    case labelRegionName
    case labelCity
    case labelZipCode
    case labelTimezone
    case labelIsp
    case labelOrg
    
    var localized: String {
        NSLocalizedString(String(describing: Self.self) + "_\(rawValue)", comment: "")
    }
}


