//
//  ThirdVCStrings.swift
//  TestTask#3
//
//  Created by MaxK on 27.04.2024.
//

import Foundation

enum ThirdString: String {
    case labelRateApp
    case labelShareApp
    case labelContactUs
    case messageToShare
    
    var localized: String {
        NSLocalizedString(String(describing: Self.self) + "_\(rawValue)", comment: "")
    }
}
