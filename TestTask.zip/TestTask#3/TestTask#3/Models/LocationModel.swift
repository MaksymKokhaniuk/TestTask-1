//
//  LocationModel.swift
//  TestTask#3
//
//  Created by MaxK on 27.04.2024.
//

import Foundation

struct LocationModel: Codable {
    let country: String
    let countryCode: String
    let region: String
    let regionName: String
    let city: String
    let zip: String
    let lat: Double
    let lon: Double
    let timezone: String
    let isp: String
    let org: String
}
