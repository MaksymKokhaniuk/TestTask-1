//
//  SecondVC.swift
//  TestTask#3
//
//  Created by MaxK on 26.04.2024.
//

import UIKit
import Alamofire
import MapKit

class SecondVC: UIViewController {
    
    let viewModel = LocationViewModel()
    let mapView = MKMapView()
    var labelsLeft: [UILabel] = []
    var labelsRight: [UILabel] = []
    var cachedLocation: LocationModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .darkGray
        setupUI()
        fetchLocationDetails()
    }
    
    @IBAction func reloadButtonTapped(_ sender: Any) {
        clearLabels()
        fetchLocationDetails()
    }
    
    func setupUI() {
        mapView.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: 200)
        mapView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(mapView)
        
        let labelInfoLeft: [(String, CGFloat)] = [(SecondString.labelCountry.localized, 220), (SecondString.labelRegion.localized, 250), (SecondString.labelCity.localized, 280), (SecondString.labelTimezone.localized, 310), (SecondString.labelIsp.localized, 340), (SecondString.labelOrg.localized, 370)]
        let labelInfoRight: [(String, CGFloat)] = [(SecondString.labelCountryCode.localized, 220), (SecondString.labelRegionName.localized, 250), (SecondString.labelZipCode.localized, 280)]
        
        for (text, yPos) in labelInfoLeft {
            let label = UILabel(frame: CGRect(x: 20, y: yPos, width: view.bounds.width - 40, height: 30))
            label.textColor = .systemYellow
            label.text = text
            label.alpha = 0.0
            view.addSubview(label)
            labelsLeft.append(label)
        }
        
        for (text, yPos) in labelInfoRight {
            let label = UILabel(frame: CGRect(x: 180, y: yPos, width: view.bounds.width - 40, height: 30))
            label.textColor = .systemYellow
            label.text = text
            label.alpha = 0.0
            view.addSubview(label)
            labelsRight.append(label)
        }
    }
    
    func fetchLocationDetails() {
        if let cachedLocation = cachedLocation {
            updateUI(with: cachedLocation)
        } else {
            viewModel.fetchLocation { result in
                switch result {
                case .success(let location):
                    print("Location Details: \(location)")
                    DispatchQueue.main.async {
                        self.showLocationOnMap(latitude: location.lat, longitude: location.lon)
                        self.updateUI(with: location)
                        self.cachedLocation = location
                    }
                case .failure(let error):
                    print("Error fetching location details: \(error)")
                }
            }
        }
    }
    
    func showLocationOnMap(latitude: Double, longitude: Double) {
        mapView.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: 200)
        let location = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        let region = MKCoordinateRegion(center: location, span: span)
        mapView.setRegion(region, animated: true)
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = location
        mapView.addAnnotation(annotation)
    }
    
    func updateUI(with location: LocationModel) {
        DispatchQueue.main.async {
            UIView.transition(with: self.view, duration: 0.5, options: .transitionCrossDissolve, animations: {
                self.labelsLeft[0].text = "\(SecondString.labelCountry.localized) \(location.country)"
                self.labelsLeft[1].text = "\(SecondString.labelRegion.localized) \(location.region)"
                self.labelsLeft[2].text = "\(SecondString.labelCity.localized) \(location.city)"
                self.labelsLeft[3].text = "\(SecondString.labelTimezone.localized) \(location.timezone)"
                self.labelsLeft[4].text = "\(SecondString.labelIsp.localized) \(location.isp)"
                self.labelsLeft[5].text = "\(SecondString.labelOrg.localized) \(location.org)"
                self.labelsRight[0].text = "\(SecondString.labelCountryCode.localized) \(location.countryCode)"
                self.labelsRight[1].text = "\(SecondString.labelRegionName.localized) \(location.regionName)"
                self.labelsRight[2].text = "\(SecondString.labelZipCode.localized) \(location.zip)"
                self.animateLabelsAppearance(labels: self.labelsLeft)
                self.animateLabelsAppearance(labels: self.labelsRight)
            }, completion: nil)
        }
    }
    
    func animateLabelsAppearance(labels: [UILabel]) {
        for (index, label) in labels.enumerated() {
            UIView.animate(withDuration: 1, delay: Double(index) * 0.5, options: .curveEaseInOut, animations: {
                label.alpha = 1.0
            }, completion: nil)
        }
    }
    
    func clearLabels() {
        for label in labelsLeft + labelsRight {
            label.text = ""
        }
    }
}
