//
//  ThirdVC.swift
//  TestTask#3
//
//  Created by MaxK on 26.04.2024.
//

import UIKit
import StoreKit

class ThirdVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let options = [ThirdString.labelRateApp.localized, ThirdString.labelShareApp.localized, ThirdString.labelContactUs.localized]
    
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: view.bounds, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .darkGray
        view.addSubview(tableView)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return options.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = options[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0: rateApp()
        case 1: shareApp()
        case 2: contactUs()
        default: break
        }
        tableView.deselectRow(at: indexPath, animated: true) // Скасувати виділення рядка після натискання
    }
    
    func rateApp() {
        SKStoreReviewController.requestReview()
    }
    
    func shareApp() {
        let textToShare = ThirdString.messageToShare.localized
        
        let appStoreLink = URL(string: "https://energise.notion.site/Swift-fac45cd4d51640928ce8e7ea38552fc3")!
        let objectsToShare: [Any] = [textToShare, appStoreLink]
        
        let activityViewController = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = view // Для iPad
        
        present(activityViewController, animated: true, completion: nil)
    }
    
    func contactUs() {
        if let url = URL(string: "https://energise.notion.site/Swift-fac45cd4d51640928ce8e7ea38552fc3") {
            UIApplication.shared.open(url)
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.backgroundColor = .clear
    }
}
