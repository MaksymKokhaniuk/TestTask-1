//
//  ViewController.swift
//  TestTask#3
//
//  Created by MaxK on 26.04.2024.
//

import UIKit

class MainVC: UIViewController {
    var playButtonSize: CGFloat = 100
    let pulseAnimationKey = "pulseAnimation"
    var isPlaying: Bool = false
    var timer: Timer?
    var seconds: Int = 0
    var anim: Bool = true
    
    lazy var playButton: UIButton = {
        let button = UIButton(type: .system)
        button.frame = CGRect(x: (view.frame.width - playButtonSize) / 2, y: (view.frame.height - playButtonSize) / 2, width: playButtonSize, height: playButtonSize)
        let playImage = UIImage(systemName: "play.fill") // Зображення кнопки "Play"
        button.setImage(playImage, for: .normal)
        button.tintColor = .white // Колір кнопки
        button.addTarget(self, action: #selector(playButtonTapped), for: .touchUpInside)
        return button
    }()
    
    lazy var timerLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 36)
        label.textColor = .systemYellow
        label.textAlignment = .center
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .darkGray
        self.tabBarController?.delegate = self
        view.addSubview(playButton)
        view.addSubview(timerLabel)
        startPulseAnimation(for: playButton.layer)
        updateTimerLabelFrame()
    }
    
    @objc func playButtonTapped() {
        if isPlaying {
            pauseTimer()
            playButton.setImage(UIImage(systemName: "play.fill"), for: .normal)
            startPulseAnimation(for: playButton.layer)
            seconds = 0
            updateTimerLabel()
            isPlaying = false
        } else {
            startTimer()
            playButton.setImage(UIImage(systemName: "pause.fill"), for: .normal)
            playButton.layer.removeAllAnimations()
            isPlaying = true
        }
    }
    
    func updateTimerLabelFrame() {
        let timerLabelSize: CGFloat = 50
        timerLabel.frame = CGRect(x: (view.frame.width - timerLabelSize * 3) / 2,
                                  y: (view.frame.height - playButtonSize) / 2 - timerLabelSize - 20,
                                  width: timerLabelSize * 3,
                                  height: timerLabelSize)
        timerLabel.text = "00:00:00"
    }
    
    func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
        startPulseAnimation(for: timerLabel.layer)
    }
    
    func pauseTimer() {
        timer?.invalidate()
        timer = nil
        stopPulseAnimationForTimer()
    }
    
    @objc func updateTimer() {
        seconds += 1
        updateTimerLabel()
    }
    
    func updateTimerLabel() {
        let hours = seconds / 3600
        let minutes = (seconds % 3600) / 60
        let seconds = (seconds % 3600) % 60
        timerLabel.text = String(format: "%02d:%02d:%02d", hours, minutes, seconds)
    }
    
    func startPulseAnimation(for layer: CALayer) {
        let pulseAnimation = CABasicAnimation(keyPath: "transform.scale")
        pulseAnimation.duration = 1.5
        pulseAnimation.fromValue = 1.0
        pulseAnimation.toValue = 1.4
        pulseAnimation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        pulseAnimation.autoreverses = true
        pulseAnimation.repeatCount = .infinity
        layer.add(pulseAnimation, forKey: pulseAnimationKey)
    }
    
    func stopPulseAnimationForTimer() {
        timerLabel.layer.removeAnimation(forKey: pulseAnimationKey)
    }
}

extension MainVC: UITabBarControllerDelegate {
    func tabBarController(_ tabBarController: UITabBarController, animationControllerForTransitionFrom fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return CustomTabBarTransition()
    }
}
