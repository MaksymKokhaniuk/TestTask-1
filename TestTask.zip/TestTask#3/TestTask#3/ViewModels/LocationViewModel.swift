//
//  LocationViewModel.swift
//  TestTask#3
//
//  Created by MaxK on 27.04.2024.
//

import Foundation
import Alamofire

class LocationViewModel {
    
    let url = "http://ip-api.com/json/"
        
        func fetchLocation(completion: @escaping (Result<LocationModel, Error>) -> Void) {
            AF.request(url).responseJSON { response in
                switch response.result {
                case .success(let value):
                    self.handleSuccessResponse(value: value, completion: completion)
                case .failure(let error):
                    completion(.failure(error))
                }
            }
        }
        
        private func handleSuccessResponse(value: Any, completion: @escaping (Result<LocationModel, Error>) -> Void) {
            if let json = value as? [String: Any] {
                let location = LocationModel(
                    country: json["country"] as? String ?? "",
                    countryCode: json["countryCode"] as? String ?? "",
                    region: json["region"] as? String ?? "",
                    regionName: json["regionName"] as? String ?? "",
                    city: json["city"] as? String ?? "",
                    zip: json["zip"] as? String ?? "",
                    lat: json["lat"] as? Double ?? 0,
                    lon: json["lon"] as? Double ?? 0,
                    timezone: json["timezone"] as? String ?? "",
                    isp: json["isp"] as? String ?? "",
                    org: json["org"] as? String ?? ""
                )
                completion(.success(location))
            } else {
                let error = NSError(domain: "ParsingError", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to parse JSON"])
                completion(.failure(error))
            }
        }
}
