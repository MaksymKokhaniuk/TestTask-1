//
//  CustomTabBarTransition.swift
//  TestTask#3
//
//  Created by MaxK on 26.04.2024.
//

import UIKit

class CustomTabBarTransition: NSObject, UIViewControllerAnimatedTransitioning {
    
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.6
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        guard let fromVC = transitionContext.viewController(forKey: .from),
                  let toVC = transitionContext.viewController(forKey: .to),
                  let fromView = transitionContext.view(forKey: .from),
                  let toView = transitionContext.view(forKey: .to) else {
                return
            }

            let containerView = transitionContext.containerView
            // Налаштуйте початкове та кінцеве положення представлень (fromView та toView)

            // Додайте toView на containerView (якщо він ще не доданий)
            if toView.superview == nil {
                containerView.addSubview(toView)
            }

            // Налаштуйте початковий та кінцевий стан ваших представлень
            toView.alpha = 0.0 // Встановіть альфа-канал для початкової прозорості

            // Виконайте анімацію
            UIView.animate(withDuration: transitionDuration(using: transitionContext), animations: {
                // Змініть властивості представлень для створення анімації
                fromView.alpha = 0 // Поїхати назад, зникнути
                toView.alpha = 1 // З'явитися
            }) { (finished) in
                // Позначте завершення анімації
                transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
            }
    }
    
    
}
